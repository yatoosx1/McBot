from mcpi.minecraft import Minecraft
import time
import openai

# Minecraft'a bağlan
mc = Minecraft.create("localhost", 4711)  # Sunucu adresini değiştir

# ChatGPT API anahtarını buraya ekle
openai.api_key = 'YOUR_OPENAI_API_KEY'

# Bot ismi
bot_name = "ChatGPTBot"

# Komutları kontrol etme ve işleme fonksiyonu
def process_command(command, player_name):
    if command == "help":
        send_message_to_minecraft(f"{player_name}, kullanabileceğiniz komutlar: /help, /chatgpt, /time, /placeblock")
    elif command.startswith("chatgpt"):
        query = command[len("chatgpt "):]
        response = get_chatgpt_response(query)
        send_message_to_minecraft(f"ChatGPT: {response}")
    elif command == "time":
        send_message_to_minecraft(f"Zaman: {time.strftime('%H:%M:%S')}")
    elif command.startswith("placeblock"):
        args = command.split()
        if len(args) == 4:
            try:
                x, y, z = int(args[1]), int(args[2]), int(args[3])
                mc.setBlock(x, y, z, 1)  # 1 ID, örneğin taş bloğu
                send_message_to_minecraft(f"Block placed at {x}, {y}, {z}")
            except ValueError:
                send_message_to_minecraft("Geçersiz koordinatlar.")
        else:
            send_message_to_minecraft("Komutun doğru formatı: /placeblock <x> <y> <z>")

# Minecraft'a mesaj gönderme fonksiyonu
def send_message_to_minecraft(message):
    mc.postToChat(message)

# ChatGPT ile mesajlaşma fonksiyonu
def get_chatgpt_response(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",  # En güncel model
        prompt=prompt,
        max_tokens=150,
        temperature=0.7
    )
    return response.choices[0].text.strip()

# Komutları dinle ve işle
def listen_to_minecraft_chat():
    while True:
        chat_messages = mc.events.pollChatPosts()  # Minecraft chat mesajlarını al
        for message in chat_messages:
            player_name = message['author']  # Mesajı atan oyuncunun ismi
            msg = message['message']  # Mesajın içeriği

            # Eğer bot komutları varsa işlem yap
            if msg.startswith("/"):
                command = msg[1:]  # Komut kısmını al
                process_command(command, player_name)
        time.sleep(1)

# Ana fonksiyon
def main():
    send_message_to_minecraft(f"{bot_name} Minecraft sunucusuna katıldı!")
    print(f"{bot_name} Minecraft sunucusuna bağlandı!")

    # Minecraft chat'ini dinle
    listen_to_minecraft_chat()

# Botu çalıştır
if __name__ == "__main__":
    main()
